/*
 ============================================================================
 Name        : 2020HW3starter.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include "tests.h"
/*#include "Prototype.h"
#include "production.c"
#include "TMSName.h"
*/
#include "hello.h"
#include "prod.h"
int main(int argc, char* argv[]) {
	puts("!!!Let's do  HW3!!!"); /* prints !!!Hello World!!! */
	/*testing();
	if(testing())
	{
		puts("About to run production.");
		production(argc, argv);
	}
	else
	{
		 puts("Tests did not pass.");
		 production(argc, argv);
	}
	return EXIT_SUCCESS;*/
	printf("Hello world");
	//function();
}
