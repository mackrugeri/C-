
// Q2a: Define displayEmployee() for Nontechnical class (5 points)
// Define the function displayEmployee() that you declared within the Nontechnical class in the header file
// See expected output in question file.

// (displayList() function in hw9.cpp should call this function.)
// Include necessary header files

