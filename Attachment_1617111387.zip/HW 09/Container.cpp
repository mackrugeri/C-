#include "Container.h"

// Constructor for Container class
Container::Container()
{
	emp = NULL;
	next = NULL;
}