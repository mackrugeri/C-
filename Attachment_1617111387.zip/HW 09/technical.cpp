
// Q2b: Define displayEmployee() for Technical class (5 points)
// Define the function displayEmployee() that you declared within the Technical class in the header file
// See expected output in question file.

// (displayList() function in hw9.cpp should call this function.)
// Include necessary header files
